import { Task, STATUS } from "./task";


export const Tasks: Task[] = [
  {
    id: 1,
    task: 'Exercise day', 
    description: 'To  get healthy', 
    status: STATUS.completed,
    created: Date.now()
  },
  {
    id: 2,
    task: 'The Radical Honesty of Vanity', 
    description: 'the-radical-honesty-of-vanity', 
    status: STATUS.completed,
    created: Date.now()
  },
  {
    id: 3,
    task: 'Why do all Pixar movies have the same story?', 
    description: 'why-do-all-pixar-movies-have-the-same-story', 
    status: STATUS.notCompleted,
    created: Date.now()
  },
  {
    id: 4,
    task: 'Style on Demand', 
    description: 'style-on-demand', 
    status: STATUS.completed,
    created: Date.now()
  },
  {
    id: 5,
    task: 'What Happens to Farming When Water Is 10x More Expensive & Labor Is Scarce?', 
    description: 'what-happens-to-farming-when-water-is-10x-more-expensive-labor-is-scarce', 
    status: STATUS.notCompleted,
    created: Date.now()
  },
  
];