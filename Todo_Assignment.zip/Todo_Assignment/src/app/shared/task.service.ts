import { Injectable } from '@angular/core';
import { Task } from './task';
import { Tasks } from './mock-tasks';


@Injectable()
export class TaskService {

  idGen: number = Tasks.length;

  constructor() {}

  getTasks(): Task[] {
    return Tasks;
  }

  getTaskById(id: number): Task {
    const index = this._findIndexById(id);
    return Tasks[index];
  }

  storeTask(newtask: any) {
    this.idGen++;

    Tasks.push({
      id: this.idGen,
      task: newtask.task,
      description: newtask.description,
      status: newtask.status,
      created: Date.now()
    });
  }

  updateTask(id: number, newtask: any) {
    let tsk = Tasks[this._findIndexById(id)];

    tsk.task = newtask.task;
    tsk.description = newtask.description;
    tsk.status = newtask.status;
  }

  deleteTask(obj: Task) {
    const index = Tasks.indexOf(obj);
    Tasks.splice(index , 1);
  }

  private _findIndexById(id: number): number {
    return Tasks.findIndex(function (element) {
      return element.id === id;
    });
  }

}
