import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { SnackBarComponent } from '../snack-bar/snack-bar.component';
import { SNACKBAR_SUCCESS, SNACKBAR_DEFAULT_DURATION, SNACKBAR_ERROR, SNACKBAR_DELETE_SUCCESS } from './snack-bar.constant';

@Injectable()
export class SnackBarHelperService {

  constructor(private snackBar: MatSnackBar) { }

  popInfo(message: string): void {
    this.snackBar.openFromComponent(SnackBarComponent, { data: message, duration: SNACKBAR_DEFAULT_DURATION });
  }

  popSuccess(message: string, duration?: number): void {
    this.snackBar.openFromComponent(SnackBarComponent, {
      data: message, panelClass: SNACKBAR_SUCCESS, duration: duration ? duration : SNACKBAR_DEFAULT_DURATION
    });
  }

  popDeleteSuccess(message: string): void {
    this.snackBar.openFromComponent(SnackBarComponent, {
      data: message, panelClass: SNACKBAR_DELETE_SUCCESS, duration: SNACKBAR_DEFAULT_DURATION
    });
  }

  popWarning(message: string): void {
    this.snackBar.openFromComponent(SnackBarComponent, { data: message, duration: SNACKBAR_DEFAULT_DURATION });
  }

  popError(message: string): void {
    this.snackBar.openFromComponent(SnackBarComponent, { data: message, panelClass: SNACKBAR_ERROR });
  }

  dismissSnackBar() {
    this.snackBar.dismiss();
  }
}
