export const SNACKBAR_ERROR = 'error';
export const SNACKBAR_SUCCESS = 'success';
export const SNACKBAR_DELETE_SUCCESS = 'delete-success';

export const SNACKBAR_DEFAULT_DURATION = 2000;
export const SNACKBAR_EXTENDED_TIME = 4000;