export enum STATUS {completed = 'Completed', notCompleted = 'NotCompleted'};

export interface Task {
  id: number;
  task: string;
  description: string;
  status: STATUS;
  created: number;
}