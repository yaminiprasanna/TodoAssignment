// import { PipesPipe } from './pipes.pipe';

// describe('PipesPipe', () => {
//   it('create an instance', () => {
//     const pipe = new PipesPipe();
//     expect(pipe).toBeTruthy();
//   });
// });
