import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';

import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { TaskService } from '../shared/task.service';
import { Task } from '../shared/task';
import { LoaderHelperService } from '../_services/loader-helper.service';


@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  displayedColumns = ['task', 'description', 'created', 'status', 'actions'];
  dataSource: MatTableDataSource<Task>;

  constructor(
    public dialog: MatDialog,
    private taskService: TaskService,
    public snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.dataSource = new MatTableDataSource<Task>(this.getData());
  }
 
  getData() {
    return this.taskService.getTasks();
    //this.loaderService.hideLoader();
  }

  applyFilter(value: string) {
    value = value.trim().toLowerCase();
    this.dataSource.filter = value;
  }

  confirm(item: Task) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '540px',
      data: { title: item.task }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.delete(item);
      }
    });
  }

  delete(obj: Task) {
    this.taskService.deleteTask(obj);
    this.dataSource._updateChangeSubscription();
    this.snackBar.open('Task deleted', 'dismiss', {
      duration: 2000,
    });
  }

}