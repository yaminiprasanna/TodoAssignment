import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AppConfig } from '../app.config';

@Injectable({ providedIn:'root' })
export class UserService {
    constructor(private http: HttpClient, private config:AppConfig) { }

    getAll() {
        return this.http.get<any[]>(`${this.config.apiUrl}/users`);
    }

    register(user) {
        return this.http.post(`${this.config.apiUrl}/users/register`, user);
    }

    delete(id) {
        return this.http.delete(`${this.config.apiUrl}/users/${id}`);
    }
}